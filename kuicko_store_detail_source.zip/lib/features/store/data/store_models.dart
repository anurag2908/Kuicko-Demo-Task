class Store {
  const Store({
    required this.name,
    required this.cuisine,
    required this.rating,
    required this.reviewCount,
    required this.deliveryMinutes,
    required this.deliveryFee,
    required this.minimumOrder,
    required this.address,
    required this.heroImage,
    required this.categories,
    required this.menuItems,
  });

  final String name;
  final String cuisine;
  final double rating;
  final int reviewCount;
  final String deliveryMinutes;
  final double deliveryFee;
  final double minimumOrder;
  final String address;
  final String heroImage;
  final List<String> categories;
  final List<MenuItem> menuItems;
}

class MenuItem {
  const MenuItem({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.category,
    required this.image,
    this.isPopular = false,
    this.isVegetarian = false,
  });

  final String id;
  final String name;
  final String description;
  final double price;
  final String category;
  final String image;
  final bool isPopular;
  final bool isVegetarian;
}

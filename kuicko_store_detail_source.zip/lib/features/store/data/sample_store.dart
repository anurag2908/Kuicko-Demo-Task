import 'store_models.dart';

const sampleStore = Store(
  name: "Luca's Kitchen",
  cuisine: 'Burgers · American · Comfort food',
  rating: 4.7,
  reviewCount: 1200,
  deliveryMinutes: '25–35 min',
  deliveryFee: 5,
  minimumOrder: 20,
  address: 'Business Bay, Dubai',
  heroImage: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1400&q=85',
  categories: ['Popular', 'Burgers', 'Bowls', 'Sides', 'Drinks'],
  menuItems: [
    MenuItem(
      id: 'classic-smash',
      name: 'Classic Smash',
      description:
          'Smashed beef patty, American cheese, pickles, onions & house sauce.',
      price: 42,
      category: 'Burgers',
      image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80',
      isPopular: true,
    ),
    MenuItem(
      id: 'truffle-mushroom',
      name: 'Truffle Mushroom',
      description:
          'Double patty, wild mushrooms, Swiss cheese & creamy truffle mayo.',
      price: 49,
      category: 'Burgers',
      image: 'https://images.unsplash.com/photo-1553979459-d2229ba7433a?auto=format&fit=crop&w=600&q=80',
      isPopular: true,
    ),
    MenuItem(
      id: 'crispy-chicken',
      name: 'Crispy Chicken Sando',
      description:
          'Buttermilk fried chicken, crunchy slaw, pickles & spicy honey.',
      price: 39,
      category: 'Burgers',
      image: 'https://images.unsplash.com/photo-1606755962773-d324e0a13086?auto=format&fit=crop&w=600&q=80',
    ),
    MenuItem(
      id: 'green-goddess',
      name: 'Green Goddess Bowl',
      description: 'Avocado, quinoa, cucumber, edamame & herby lemon dressing.',
      price: 36,
      category: 'Bowls',
      image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=600&q=80',
      isVegetarian: true,
      isPopular: true,
    ),
    MenuItem(
      id: 'loaded-fries',
      name: 'Luca’s Loaded Fries',
      description:
          'Crispy fries, cheese sauce, spring onion & house seasoning.',
      price: 24,
      category: 'Sides',
      image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=600&q=80',
      isVegetarian: true,
    ),
    MenuItem(
      id: 'lemonade',
      name: 'Fresh Lemonade',
      description: 'Freshly squeezed lemons with a hint of mint.',
      price: 16,
      category: 'Drinks',
      image: 'https://images.unsplash.com/photo-1513558161293-cdad765edc89?auto=format&fit=crop&w=600&q=80',
      isVegetarian: true,
    ),
  ],
);

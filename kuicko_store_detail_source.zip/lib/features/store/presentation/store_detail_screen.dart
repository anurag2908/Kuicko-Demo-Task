import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc/store_bloc.dart';
import '../bloc/store_event.dart';
import '../bloc/store_state.dart';
import '../data/store_models.dart';

const _ink = Color(0xFF202124);
const _muted = Color(0xFF777A80);
const _line = Color(0xFFEDEDEF);
const _accent = Color(0xFFE84242);

class StoreDetailScreen extends StatefulWidget {
  const StoreDetailScreen({super.key});

  @override
  State<StoreDetailScreen> createState() => _StoreDetailScreenState();
}

class _StoreDetailScreenState extends State<StoreDetailScreen> {
  final _menuKey = GlobalKey();
  final _searchFocusNode = FocusNode();

  @override
  void dispose() {
    _searchFocusNode.dispose();
    super.dispose();
  }

  Future<void> _focusMenuSearch() async {
    final menuContext = _menuKey.currentContext;
    if (menuContext == null) return;
    await Scrollable.ensureVisible(
      menuContext,
      duration: const Duration(milliseconds: 350),
      alignment: .1,
    );
    if (mounted) _searchFocusNode.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<StoreBloc, StoreState>(
      builder: (context, state) {
        return Scaffold(
          body: SafeArea(
            top: false,
            child: CustomScrollView(
              slivers: [
                SliverToBoxAdapter(
                  child: _StoreHero(
                    store: state.store,
                    onSearch: _focusMenuSearch,
                  ),
                ),
                SliverToBoxAdapter(
                  child: _StoreInformation(
                    store: state.store,
                    isFavorite: state.isFavorite,
                  ),
                ),
                const SliverToBoxAdapter(child: _OfferCard()),
                SliverToBoxAdapter(
                  child: _MenuSection(
                    key: _menuKey,
                    store: state.store,
                    state: state,
                    searchFocusNode: _searchFocusNode,
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 2, 16, 28),
                  sliver: SliverList.separated(
                    itemCount: state.visibleItems.length,
                    separatorBuilder: (context, index) =>
                        const Divider(height: 1, indent: 0, color: _line),
                    itemBuilder: (context, index) {
                      final item = state.visibleItems[index];
                      return _MenuItemTile(
                        item: item,
                        quantity: state.cartQuantities[item.id] ?? 0,
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          bottomNavigationBar: state.cartItemCount == 0
              ? const _BottomNavigation()
              : _BasketBar(state: state),
        );
      },
    );
  }
}

class _StoreHero extends StatelessWidget {
  const _StoreHero({required this.store, required this.onSearch});

  final Store store;
  final VoidCallback onSearch;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 264,
      child: Stack(
        fit: StackFit.expand,
        children: [
          _Photo(
            url: store.heroImage,
            icon: Icons.restaurant,
            fit: BoxFit.cover,
          ),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0x66000000),
                  Colors.transparent,
                  Color(0x33000000),
                ],
                stops: [0, .35, 1],
              ),
            ),
          ),
          Positioned(
            top: MediaQuery.paddingOf(context).top + 12,
            left: 16,
            right: 16,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _RoundButton(
                  icon: Icons.arrow_back_rounded,
                  label: 'Go back',
                  onPressed: () => Navigator.of(context).maybePop(),
                ),
                Row(
                  children: [
                    _RoundButton(
                      icon: Icons.search_rounded,
                      label: 'Search menu',
                      onPressed: onSearch,
                    ),
                    const SizedBox(width: 10),
                    _RoundButton(
                      icon: Icons.ios_share_rounded,
                      label: 'Share store',
                      onPressed: () =>
                          _showMessage(context, 'Store link copied'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Positioned(
            left: 16,
            bottom: 14,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.local_fire_department, size: 15, color: _accent),
                  SizedBox(width: 5),
                  Text(
                    'POPULAR IN DUBAI',
                    style: TextStyle(
                      color: _ink,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: .5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StoreInformation extends StatelessWidget {
  const _StoreInformation({required this.store, required this.isFavorite});

  final Store store;
  final bool isFavorite;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      store.name,
                      style: const TextStyle(
                        color: _ink,
                        fontSize: 25,
                        height: 1.15,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -.5,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      store.cuisine,
                      style: const TextStyle(fontSize: 13, color: _muted),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Column(
                children: [
                  IconButton(
                    onPressed: () => context.read<StoreBloc>().add(
                      const StoreFavoriteToggled(),
                    ),
                    visualDensity: VisualDensity.compact,
                    icon: Icon(
                      isFavorite ? Icons.favorite : Icons.favorite_border,
                      color: isFavorite ? _accent : _ink,
                      size: 24,
                    ),
                    tooltip: 'Save store',
                  ),
                  const Text(
                    'FAVOURITE',
                    style: TextStyle(
                      fontSize: 8,
                      color: _muted,
                      fontWeight: FontWeight.w700,
                      letterSpacing: .45,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 15),
          Wrap(
            spacing: 12,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.star_rounded,
                    size: 17,
                    color: Color(0xFFF5A623),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '${store.rating}',
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: _ink,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '(${(store.reviewCount / 1000).toStringAsFixed(1)}k+)',
                    style: const TextStyle(fontSize: 12, color: _muted),
                  ),
                ],
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.access_time_rounded,
                    size: 15,
                    color: _muted,
                  ),
                  const SizedBox(width: 5),
                  Text(
                    store.deliveryMinutes,
                    style: const TextStyle(fontSize: 12, color: _ink),
                  ),
                ],
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.delivery_dining, size: 17, color: _muted),
                  const SizedBox(width: 3),
                  Text(
                    'AED ${store.deliveryFee.toStringAsFixed(0)}',
                    style: const TextStyle(fontSize: 12, color: _ink),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 15),
          Container(height: 1, color: _line),
          const SizedBox(height: 13),
          Row(
            children: [
              const Icon(Icons.location_on_outlined, size: 18, color: _muted),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'Deliver to  •  ${store.address}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12, color: _muted),
                ),
              ),
              const Icon(Icons.keyboard_arrow_down, size: 18, color: _ink),
            ],
          ),
        ],
      ),
    );
  }
}

class _OfferCard extends StatelessWidget {
  const _OfferCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 14, 16, 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF6E8),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF5E7CF)),
      ),
      child: Row(
        children: [
          Container(
            height: 38,
            width: 38,
            decoration: BoxDecoration(
              color: const Color(0xFFFFE6B8),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.local_offer_rounded,
              color: Color(0xFFB36B00),
              size: 20,
            ),
          ),
          const SizedBox(width: 11),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'AED 10 off your first order',
                  style: TextStyle(
                    color: _ink,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                SizedBox(height: 3),
                Text(
                  'Use code  WELCOME10  ·  Min. order AED 40',
                  style: TextStyle(color: _muted, fontSize: 10),
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_right, color: _muted, size: 19),
        ],
      ),
    );
  }
}

class _MenuSection extends StatelessWidget {
  const _MenuSection({
    super.key,
    required this.store,
    required this.state,
    required this.searchFocusNode,
  });

  final Store store;
  final StoreState state;
  final FocusNode searchFocusNode;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      margin: const EdgeInsets.only(top: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 13),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'Menu',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: _ink,
                    ),
                  ),
                ),
                Container(
                  width: 142,
                  height: 38,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF5F5F6),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: TextField(
                    focusNode: searchFocusNode,
                    onChanged: (query) => context.read<StoreBloc>().add(
                      StoreSearchChanged(query),
                    ),
                    style: const TextStyle(fontSize: 12),
                    decoration: const InputDecoration(
                      hintText: 'Search menu',
                      hintStyle: TextStyle(fontSize: 11, color: _muted),
                      prefixIcon: Icon(
                        Icons.search_rounded,
                        size: 17,
                        color: _muted,
                      ),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.only(top: 10),
                      prefixIconConstraints: BoxConstraints(
                        minWidth: 34,
                        minHeight: 34,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 45,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              scrollDirection: Axis.horizontal,
              itemCount: store.categories.length,
              separatorBuilder: (context, index) => const SizedBox(width: 8),
              itemBuilder: (context, index) {
                final category = store.categories[index];
                final selected = state.selectedCategory == category;
                return ChoiceChip(
                  label: Text(category),
                  selected: selected,
                  onSelected: (_) => context.read<StoreBloc>().add(
                    StoreCategorySelected(category),
                  ),
                  showCheckmark: false,
                  labelStyle: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: selected ? Colors.white : _ink,
                  ),
                  backgroundColor: Colors.white,
                  selectedColor: _ink,
                  side: BorderSide(color: selected ? _ink : _line),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 19, 16, 5),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'Bestsellers',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: _ink,
                    ),
                  ),
                ),
                Text(
                  '${state.visibleItems.length} items',
                  style: const TextStyle(fontSize: 11, color: _muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MenuItemTile extends StatelessWidget {
  const _MenuItemTile({required this.item, required this.quantity});

  final MenuItem item;
  final int quantity;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    if (item.isVegetarian)
                      const Padding(
                        padding: EdgeInsets.only(right: 5),
                        child: Icon(
                          Icons.eco_outlined,
                          size: 15,
                          color: Color(0xFF368B55),
                        ),
                      ),
                    Flexible(
                      child: Text(
                        item.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          color: _ink,
                        ),
                      ),
                    ),
                  ],
                ),
                if (item.isPopular) ...[
                  const SizedBox(height: 4),
                  const Row(
                    children: [
                      Icon(
                        Icons.local_fire_department,
                        color: _accent,
                        size: 13,
                      ),
                      SizedBox(width: 3),
                      Text(
                        'Bestseller',
                        style: TextStyle(
                          color: _accent,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ],
                const SizedBox(height: 6),
                Text(
                  item.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _muted,
                    fontSize: 11,
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'AED ${item.price.toStringAsFixed(0)}',
                  style: const TextStyle(
                    color: _ink,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          SizedBox(
            width: 102,
            height: 96,
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: _Photo(
                    url: item.image,
                    icon: Icons.fastfood_rounded,
                    fit: BoxFit.cover,
                  ),
                ),
                Positioned(
                  bottom: -7,
                  left: 15,
                  right: 15,
                  child: quantity == 0
                      ? _AddButton(onPressed: () => _addItem(context))
                      : _QuantityControl(
                          quantity: quantity,
                          onAdd: () => _addItem(context),
                          onRemove: () => _removeItem(context),
                        ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _addItem(BuildContext context) {
    context.read<StoreBloc>().add(StoreItemAdded(item.id));
  }

  void _removeItem(BuildContext context) {
    context.read<StoreBloc>().add(StoreItemRemoved(item.id));
  }
}

class _AddButton extends StatelessWidget {
  const _AddButton({required this.onPressed});

  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 29,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: _accent,
          side: const BorderSide(color: _line),
          padding: EdgeInsets.zero,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(7)),
          elevation: 2,
        ),
        child: const Text(
          'ADD',
          style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800),
        ),
      ),
    );
  }
}

class _QuantityControl extends StatelessWidget {
  const _QuantityControl({
    required this.quantity,
    required this.onAdd,
    required this.onRemove,
  });

  final int quantity;
  final VoidCallback onAdd;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 29,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(7),
        border: Border.all(color: _line),
        boxShadow: const [
          BoxShadow(
            color: Color(0x18000000),
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _QuantityIcon(icon: Icons.remove, onPressed: onRemove),
          Text(
            '$quantity',
            style: const TextStyle(
              color: _ink,
              fontSize: 12,
              fontWeight: FontWeight.w800,
            ),
          ),
          _QuantityIcon(icon: Icons.add, onPressed: onAdd),
        ],
      ),
    );
  }
}

class _QuantityIcon extends StatelessWidget {
  const _QuantityIcon({required this.icon, required this.onPressed});

  final IconData icon;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPressed,
      child: Icon(icon, size: 16, color: _accent),
    );
  }
}

class _BasketBar extends StatelessWidget {
  const _BasketBar({required this.state});

  final StoreState state;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      minimum: const EdgeInsets.fromLTRB(16, 8, 16, 10),
      child: SizedBox(
        height: 52,
        child: FilledButton(
          onPressed: () => _showMessage(context, 'Your basket is ready'),
          style: FilledButton.styleFrom(
            backgroundColor: _accent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: .2),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  '${state.cartItemCount}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  'View basket',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
                ),
              ),
              Text(
                'AED ${state.cartTotal.toStringAsFixed(0)}',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BottomNavigation extends StatelessWidget {
  const _BottomNavigation();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        height: 62,
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: _line)),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _NavItem(icon: Icons.home_rounded, title: 'Home', selected: false),
            _NavItem(
              icon: Icons.grid_view_rounded,
              title: 'Browse',
              selected: true,
            ),
            _NavItem(
              icon: Icons.receipt_long_outlined,
              title: 'Orders',
              selected: false,
            ),
            _NavItem(
              icon: Icons.person_outline_rounded,
              title: 'Account',
              selected: false,
            ),
          ],
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.title,
    required this.selected,
  });

  final IconData icon;
  final String title;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final color = selected ? _accent : _muted;
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(height: 3),
        Text(
          title,
          style: TextStyle(
            color: color,
            fontSize: 9,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

class _RoundButton extends StatelessWidget {
  const _RoundButton({
    required this.icon,
    required this.label,
    required this.onPressed,
  });

  final IconData icon;
  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: const CircleBorder(),
      child: IconButton(
        onPressed: onPressed,
        tooltip: label,
        icon: Icon(icon, size: 20, color: _ink),
        visualDensity: VisualDensity.compact,
      ),
    );
  }
}

class _Photo extends StatelessWidget {
  const _Photo({required this.url, required this.icon, required this.fit});

  final String url;
  final IconData icon;
  final BoxFit fit;

  @override
  Widget build(BuildContext context) {
    return Image.network(
      url,
      fit: fit,
      errorBuilder: (context, error, stackTrace) => Container(
        color: const Color(0xFFE9E6E0),
        alignment: Alignment.center,
        child: Icon(icon, size: 36, color: const Color(0xFFB8B1A8)),
      ),
      loadingBuilder: (context, child, progress) {
        if (progress == null) return child;
        return Container(
          color: const Color(0xFFE9E6E0),
          alignment: Alignment.center,
          child: const SizedBox(
            height: 20,
            width: 20,
            child: CircularProgressIndicator(strokeWidth: 2, color: _accent),
          ),
        );
      },
    );
  }
}

void _showMessage(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}

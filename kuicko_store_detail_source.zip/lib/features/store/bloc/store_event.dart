sealed class StoreEvent {
  const StoreEvent();
}

class StoreCategorySelected extends StoreEvent {
  const StoreCategorySelected(this.category);

  final String category;
}

class StoreSearchChanged extends StoreEvent {
  const StoreSearchChanged(this.query);

  final String query;
}

class StoreFavoriteToggled extends StoreEvent {
  const StoreFavoriteToggled();
}

class StoreItemAdded extends StoreEvent {
  const StoreItemAdded(this.itemId);

  final String itemId;
}

class StoreItemRemoved extends StoreEvent {
  const StoreItemRemoved(this.itemId);

  final String itemId;
}

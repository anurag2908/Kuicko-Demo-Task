import 'package:flutter_bloc/flutter_bloc.dart';

import '../data/store_models.dart';
import 'store_event.dart';
import 'store_state.dart';

class StoreBloc extends Bloc<StoreEvent, StoreState> {
  StoreBloc({required Store store}) : super(StoreState(store: store)) {
    on<StoreCategorySelected>((event, emit) {
      emit(state.copyWith(selectedCategory: event.category));
    });
    on<StoreSearchChanged>((event, emit) {
      emit(state.copyWith(searchQuery: event.query));
    });
    on<StoreFavoriteToggled>((event, emit) {
      emit(state.copyWith(isFavorite: !state.isFavorite));
    });
    on<StoreItemAdded>((event, emit) {
      final nextQuantities = Map<String, int>.of(state.cartQuantities);
      nextQuantities.update(
        event.itemId,
        (quantity) => quantity + 1,
        ifAbsent: () => 1,
      );
      emit(state.copyWith(cartQuantities: Map.unmodifiable(nextQuantities)));
    });
    on<StoreItemRemoved>((event, emit) {
      final nextQuantities = Map<String, int>.of(state.cartQuantities);
      final quantity = nextQuantities[event.itemId] ?? 0;
      if (quantity <= 1) {
        nextQuantities.remove(event.itemId);
      } else {
        nextQuantities[event.itemId] = quantity - 1;
      }
      emit(state.copyWith(cartQuantities: Map.unmodifiable(nextQuantities)));
    });
  }
}

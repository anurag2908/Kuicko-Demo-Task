import '../data/store_models.dart';

class StoreState {
  const StoreState({
    required this.store,
    this.selectedCategory = 'Popular',
    this.searchQuery = '',
    this.isFavorite = false,
    this.cartQuantities = const {},
  });

  final Store store;
  final String selectedCategory;
  final String searchQuery;
  final bool isFavorite;
  final Map<String, int> cartQuantities;

  List<MenuItem> get visibleItems {
    final normalizedQuery = searchQuery.trim().toLowerCase();
    return store.menuItems.where((item) {
      final matchesCategory = selectedCategory == 'Popular'
          ? item.isPopular
          : item.category == selectedCategory;
      final matchesSearch =
          normalizedQuery.isEmpty ||
          item.name.toLowerCase().contains(normalizedQuery) ||
          item.description.toLowerCase().contains(normalizedQuery);
      return matchesCategory && matchesSearch;
    }).toList();
  }

  int get cartItemCount =>
      cartQuantities.values.fold(0, (total, quantity) => total + quantity);

  double get cartTotal => store.menuItems.fold(0, (total, item) {
    return total + item.price * (cartQuantities[item.id] ?? 0);
  });

  StoreState copyWith({
    String? selectedCategory,
    String? searchQuery,
    bool? isFavorite,
    Map<String, int>? cartQuantities,
  }) {
    return StoreState(
      store: store,
      selectedCategory: selectedCategory ?? this.selectedCategory,
      searchQuery: searchQuery ?? this.searchQuery,
      isFavorite: isFavorite ?? this.isFavorite,
      cartQuantities: cartQuantities ?? this.cartQuantities,
    );
  }
}
